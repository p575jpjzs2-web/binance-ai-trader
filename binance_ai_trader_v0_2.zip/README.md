# Binance AI Trader — Prototype 0.1

Application web mobile en français, en mode simulation uniquement.

## Contenu
- `index.html` : application complète (interface responsive).
- Aucun compte Binance ni clé API n'est connecté.
- Les prix affichés sont fictifs.
- Aucun ordre réel n'est envoyé.

## Déploiement gratuit
Publier ce dossier comme site statique sur Render. Le fichier d'entrée est `index.html`.
